 <!-- footer content -->
    <footer>
      <div class="pull-right"> Gentelella - Bootstrap Admin Template by <a href="https://colorlib.com">Colorlib</a> </div>
      <div class="clearfix"></div>
    </footer>
    <!-- /footer content --> 
  </div>
</div>

<!-- jQuery --> 
<script src="assests/js/jquery.min.js"></script> 
<!-- Bootstrap --> 
<script src="assests/js/bootstrap.min.js"></script> 
<!-- Responsive Table Data Scripts --> 
<script src="assests/js/jquery.dataTables.min.js"></script> 
<script src="assests/js/responsive.bootstrap.min.js"></script> 
<script src="assests/js/dataTables.fixedHeader.min.js"></script> 
<script src="assests/js/dataTables.keyTable.min.js"></script> 
<script src="assests/js/dataTables.responsive.min.js"></script> 
<script src="assests/js/dataTables.scroller.min.js"></script> 
<script src="assests/js/responsive.bootstrap.js"></script> 

<!-- FastClick --> 
<script src="assests/js/fastclick.js"></script> 
<!-- NProgress --> 
<script src="assests/js/nprogress.js"></script> 
<!-- Chart.js --> 
<script src="assests/js/Chart.min.js"></script> 
<!-- gauge.js --> 
<script src="assests/js/gauge.min.js"></script> 
<!-- bootstrap-progressbar --> 
<script src="assests/js/bootstrap-progressbar.min.js"></script> 
<!-- iCheck --> 
<script src="assests/js/icheck.min.js"></script> 
<!-- Skycons --> 
<script src="assests/js/skycons.js"></script> 
<!-- Flot --> 
<script src="assests/js/jquery.flot.js"></script> 
<script src="assests/js/jquery.flot.pie.js"></script> 
<script src="assests/js/jquery.flot.time.js"></script> 
<script src="assests/js/jquery.flot.stack.js"></script> 
<script src="assests/js/query.flot.resize.js"></script> 
<!-- Flot plugins --> 
<script src="assests/js/jquery.flot.orderBars.js"></script> 
<script src="assests/js/jquery.flot.spline.min.js"></script> 
<script src="assests/js/curvedLines.js"></script> 
<!-- DateJS --> 
<script src="assests/js/date.js"></script> 
<!-- JQVMap --> 
<script src="assests/js/jquery.vmap.js"></script> 
<script src="assests/js/jquery.vmap.world.js"></script> 
<script src="assests/js/jquery.vmap.sampledata.js"></script> 
<!-- bootstrap-daterangepicker --> 
<script src="assests/js/moment.min.js"></script> 
<script src="assests/js/daterangepicker.js"></script> 
<!-- File Uploader Scripts --> 
<script src="assests/js/dropzone.min.js"></script> 
<!-- Form Validations Scripts --> 
<script src="assests/js/validator.js"></script> 
<!-- Custom Theme Scripts --> 
<script src="assests/js/custom.min.js"></script>
</body>
</html>
